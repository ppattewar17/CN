import React, { useState } from "react";
import axios from "axios";

function App() {
  const [studentName, setStudentName] = useState("");
  const [subjects, setSubjects] = useState([
    { name: "Subject 1", marks30: "", marks70: "" },
    { name: "Subject 2", marks30: "", marks70: "" },
    { name: "Subject 3", marks30: "", marks70: "" },
    { name: "Subject 4", marks30: "", marks70: "" },
  ]);
  const [cgpa, setCgpa] = useState(null);

  const handleChange = (index, field, value) => {
    const updated = [...subjects];
    updated[index][field] = value;
    setSubjects(updated);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:5000/addMarks", {
        student_name: studentName,
        subjects: subjects.map(s => ({
          marks30: parseInt(s.marks30) || 0,
          marks70: parseInt(s.marks70) || 0,
        }))
      });

      setCgpa(response.data.cgpa);
      alert("Marks saved successfully!");
      setStudentName("");
      setSubjects(subjects.map(s => ({ ...s, marks30: "", marks70: "" })));
    } catch (err) {
      console.error(err);
      alert("Error saving marks");
    }
  };

  return (
    <div style={{ padding: "20px", maxWidth: "600px", margin: "auto", fontFamily: "Arial" }}>
      <h2 style={{ textAlign: "center" }}>🎓 VIT Student Marks Entry</h2>
      <form onSubmit={handleSubmit} style={{ background: "#f9f9f9", padding: "20px", borderRadius: "10px", boxShadow: "0 2px 6px rgba(0,0,0,0.1)" }}>
        
        <div style={{ marginBottom: "15px" }}>
          <label>Student Name: </label>
          <input 
            value={studentName} 
            onChange={(e) => setStudentName(e.target.value)} 
            required 
            style={{ width: "100%", padding: "8px", marginTop: "5px" }}
          />
        </div>

        {subjects.map((sub, index) => (
          <div key={index} style={{ marginBottom: "15px", padding: "10px", border: "1px solid #ddd", borderRadius: "8px" }}>
            <h4>{sub.name}</h4>
            <label>Marks (30): </label>
            <input
              type="number"
              value={sub.marks30}
              onChange={(e) => handleChange(index, "marks30", e.target.value)}
              required
              style={{ width: "80px", marginRight: "15px" }}
            />
            <label>Marks (70): </label>
            <input
              type="number"
              value={sub.marks70}
              onChange={(e) => handleChange(index, "marks70", e.target.value)}
              required
              style={{ width: "80px" }}
            />
          </div>
        ))}

        <button type="submit" style={{ padding: "10px 20px", border: "none", borderRadius: "8px", background: "#4CAF50", color: "white", cursor: "pointer" }}>
          Save Marks
        </button>
      </form>

      {cgpa && (
        <div style={{ marginTop: "20px", textAlign: "center", fontSize: "18px" }}>
          <strong>✅ CGPA: {cgpa}</strong>
        </div>
      )}
    </div>
  );
}

export default App;
