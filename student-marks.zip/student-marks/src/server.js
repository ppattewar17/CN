const express = require("express");
const mysql = require("mysql");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
app.use(cors());
app.use(bodyParser.json());

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "pgp@1792004",
  database: "studentdb"
});

db.connect(err => {
  if (err) {
    console.error("Database connection failed:", err);
    return;
  }
  console.log("MySQL Connected...");
});

app.post("/addMarks", (req, res) => {
  const { student_name, subjects } = req.body;

  const totals = subjects.map(s => s.marks30 + s.marks70);

  const cgpa = (totals.reduce((a, b) => a + b, 0) / (subjects.length * 10)).toFixed(2);

  const sql = `
    INSERT INTO student_marks 
    (student_name,
     subject1_30, subject1_70, subject1_total,
     subject2_30, subject2_70, subject2_total,
     subject3_30, subject3_70, subject3_total,
     subject4_30, subject4_70, subject4_total,
     cgpa)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  const values = [
    student_name,
    subjects[0].marks30, subjects[0].marks70, totals[0],
    subjects[1].marks30, subjects[1].marks70, totals[1],
    subjects[2].marks30, subjects[2].marks70, totals[2],
    subjects[3].marks30, subjects[3].marks70, totals[3],
    cgpa
  ];

  db.query(sql, values, (err) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "Error saving marks" });
    }
    res.json({ message: "Marks saved successfully!", cgpa });
  });
});

app.listen(5000, () => console.log("✅ Server running on port 5000"));
